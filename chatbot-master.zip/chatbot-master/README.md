# Chatbot
AI Based Chatbot

Added New GUI compatible with all browsers, mobiles with autoscroll

### Requirements
    Python >= 2.7


## Installation

2. Install the required packages.
    ```bash
    pip install -r requirements.txt
    ```

3. Run the python server.
    ```bash
    python main.py
    ```
4. Algorithm :
First we will check the pattern in AIML directories, If it is not presnt we will check our faq sections and find the most similar question according to the question asked and answer the answer corresponding to most similar question

5. You're done and let's chat with your Robot via browser.
