= Interesting brain theory based on a small amount of data

== Introduction

The brain thinks in straight lines once you do some poorly-motivated
corrections on some brain recordings.

== Methods

We took some recordings of someone's brain while we showed them stuff
that can be measured as numbers.

After that we applied some corrections to the data and plotted it on a graph.

== Results

The data looks like a straight line with a patch of points on top.

See the ![fancy figure](fancy_figure.png).

== Discussion

The graph shows a straight line.  The data comes from the brain.  Therefore the
brain thinks in straight lines.

== Conclusion

That is my theory, it is mine and belongs to me, and I own it and what it is,
too.
